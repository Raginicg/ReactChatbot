class ActionProvider {
    constructor(
     createChatBotMessage, setStateFunc) {
     this.createChatBotMessage = createChatBotMessage;
     this.setState = setStateFunc;
    }
    greet = () => {
    const message = this.createChatBotMessage("Hello User.");
    this.addMessageToState(message);
    };
    addMessageToState = (message) => {
        this.setState((prevState) => ({
            ...prevState,
            messages: [...prevState.messages, message],
        }));
    };
    complaint = () => {
        const message = this.createChatBotMessage("Your complaint is related to what");
        this.addMessageToState(message);
        };
   
        addMessageToState = (message) => {
            this.setState((prevState) => ({
                ...prevState,
                messages: [...prevState.messages, message],
            }));
        };
   
farmer = () => {
        const message = this.createChatBotMessage("Hello Farmer");

        this.addMessageToState(message);
    };
   
        addMessageToState = (message) => {
            this.setState((prevState) => ({
                ...prevState,
                messages: [...prevState.messages, message],
            }));
        };
admin = () => {
    const message = this.createChatBotMessage("Hello Admin");
    this.addMessageToState(message);
    };
       
    addMessageToState = (message) => {
        this.setState((prevState) => ({
            ...prevState,
            messages: [...prevState.messages, message],
        }));
    };
prob = () => {
    const message = this.createChatBotMessage("Reach out to the helpdesk for futher assistance");
    this.addMessageToState(message);
    };

    addMessageToState = (message) => {
        this.setState((prevState) => ({
            ...prevState,
            messages: [...prevState.messages, message],
        }));
    };

bye = () => {
    const message = this.createChatBotMessage("Thank You. Have a great Learning");
    this.addMessageToState(message);
    };

    addMessageToState = (message) => {
        this.setState((prevState) => ({
            ...prevState,
            messages: [...prevState.messages, message],
        }));
    };
}

export default ActionProvider;