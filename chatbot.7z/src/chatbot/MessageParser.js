class MessageParser {
    constructor(actionProvider, state) {
      this.actionProvider = actionProvider;
      this.state = state;
    }
 
    parse(message) {
      console.log(message);
      const lowercase = message.toLowerCase();
    if (lowercase.includes("hello")) {
      this.actionProvider.greet();
    }
    if (lowercase.includes("thank you")) {
        this.actionProvider.bye();
    }
   
    if (lowercase.includes("unable")) {
        this.actionProvider.prob();
    }
    if (lowercase.includes("complaint")) {
      this.actionProvider.complaint();
    }
    if (lowercase.includes("farmer")) {
      this.actionProvider.farmer();
    }
    if (lowercase.includes("admin")) {
      this.actionProvider.admin();
    }


    }
  }
 
  export default MessageParser;