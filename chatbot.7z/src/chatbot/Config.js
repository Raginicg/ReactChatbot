import React from "react";
import { createChatBotMessage } from "react-chatbot-kit";
//import Options from "../components/Options/Options";

const config = {
  botName: "Farming Assist Bot",
  initialMessages: [
    createChatBotMessage(`Hello. Do you want to complaint`, {
    }),
  ],
};
export default config;