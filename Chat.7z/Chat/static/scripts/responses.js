function viewBotResponse(input) {
    
    if (input == "farm" || input=="farming") {
        return "Farming is the act or process of working the ground, planting seeds, and growing edible plants.";
    } else if (input == "complaint") {
        return "Your complaint is solve by admin within 3-5 working day...";
    }else if (input == "users") {
            return "Total 3 user are present--->Admin, Dealer & Farmer"; 
    } else if (input == "advertisement" || input=="adv") {
        return "View all the offer related to farming";
    }else if (input == "comp") {
        return "Complaint is added by farmer";
    }else if (input == "result") {
        return "Farmer your complaint is solve....";
    }

    // Starting response
    if (input == "hello" || input == "hi" || input == "hye" || input == "Hello") {
        return "Hello there!!";
    } else if (input == "goodbye" || input=="bye") {
        return "Talk to you later!!";
    }else if (input == "thank you" || input=="Thank you") {
            return "Welcome";
    } else {
        return "Try to ask something else!!";
    }
    
}